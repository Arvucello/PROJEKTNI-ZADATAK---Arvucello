from flask import Flask

from app.view import main_view


def create_app(debug=False):
    app = Flask(__name__)
    app.register_blueprint(main_view.rezervacija)
    app.debug = debug

    return app


if __name__ == "__main__":
    app = create_app(debug=True)
    app.run(host='0.0.0.0')
