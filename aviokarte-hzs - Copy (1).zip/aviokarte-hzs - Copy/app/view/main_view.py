from flask import Blueprint, request, jsonify


from app.controller.main_controller import vidi_let, vidi_sve_letove, rezervisi_mesto

let = Blueprint('let', __name__, url_prefix='/let')

@let.route('/', methods= 'GET')
def letovi_view():
    if request.method == 'GET':
        svi_letovi = vidi_sve_letove()

        response_body = [l.to_dict() for l in svi_letovi]
        return jsonify(response_body), 200


@let.route('/<string:let_uuid>', methods=['GET', 'PUT', 'DELETE'])
def vidi_jedan_let(let_uuid):
    if request.method == 'GET':
        let = vidi_let(let_uuid)
        if let is None:
            return jsonify({'error': 'flight with unique id {} not found'.format(let_uuid)}), 404

        response_body = let.to_dict()
        return jsonify(response_body), 200

    if request.method == 'PUT':
        body = request.json
        rezervisano = rezervisi_mesto(body)
        if rezervisano is None:
            return jsonify({'error': 'team with unique id {} not found'.format(let_uuid)}), 404

        return jsonify(rezervisano), 200
