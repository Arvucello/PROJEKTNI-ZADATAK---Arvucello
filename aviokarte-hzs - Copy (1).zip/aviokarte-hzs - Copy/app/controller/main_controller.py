import sqlite3

from app.model.let import Let
from app.model.rezervacija import Rezervacija

DB_PATH = (r'C:\Users\elena\Desktop\aviokarte-hzs\db/hzs.db')


def _connect():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("PRAGMA foreign_keys = ON;")
    conn.commit()
    return conn


def vidi_sve_letove():
    conn = _connect()
    c = conn.cursor()
    query = """SELECT id, odakle, gde, datum FROM let"""
    c.execute(query)
    result_set = c.fetchall()

    letovi = []

    for l in result_set:
        created_let = Let(id=l[0], odakle=l[1], gde=l[2], datum=l[3])

        rezervacija_query = """SELECT id, odakle, gde, povratak, datum FROM 
        rezervacija WHERE let_id=?"""
        c.execute(rezervacija_query, (created_let.id,))
        rezervacije = c.fetchall()

        for r in rezervacije:
            created_rezervacija = Rezervacija(id=r[0], odakle=r[1], gde=r[2], povratak=r[3], datum=r[4],
                                     let=created_let)
            created_let.add_member(created_rezervacija)

        letovi.append(created_let)

    conn.commit()
    c.close()
    conn.close()

    return letovi

def vidi_let(let_uuid):
    conn = _connect()
    c = conn.cursor()
    query = """SELECT id, odakle, gde, datum, let_uuid FROM let WHERE let_uuid=?"""
    c.execute(query, (let_uuid,))
    l = c.fetchone()

    if l is None:
        return None

    created_let = Let(id=l[0], name=l[1], description=l[2], photo_url=l[3], team_uuid=l[4])

    rezervacija_query = """SELECT id, odakle, gde, povratak, datum FROM 
    rezervacija WHERE let_id=?"""
    c.execute(rezervacija_query, (created_let.id,))
    rezervacije = c.fetchall()

    for r in rezervacije:
        created_rezervacija = Rezervacija(id=r[0], odakle=r[1], gde=r[2], povratak=r[3], datum=r[4],
                                    let=created_let)
        created_let.add_rezervacija(created_rezervacija)

    conn.commit()
    c.close()
    conn.close()

    return created_let

def rezervisi_mesto(data):
    conn = _connect()
    c = conn.cursor()

    izbrisi_sve_rezervacije(data['id'])

    let_query = """UPDATE let SET odakle=?, gde=?, datum=? WHERE let_uuid=?"""

    c.execute(let_query, (data['odakle'], data['gde'], data['datum'], data['let_uuid']))

    for r in data['rezervacije']:
        member_query = """INSERT INTO Rezervacija (odakle, gde, povratak, datum, let_id) 
        VALUES (?,?,?,?,?)"""
        c.execute(member_query,
                  (r['odakle'], r['gde'], r['datum'], data['id']))
        r['id'] = c.lastrowid

    conn.commit()
    c.close()
    conn.close()
    return data


def izbrisi_sve_rezervacije(let_id):
    conn = _connect()
    try:
        with conn:
            let_query = """DELETE FROM Rezervacija WHERE let_id=?"""
            status = conn.execute(let_query, (let_id,))
            success = False
            if status.rowcount > 0:
                success = True

            return success
    except sqlite3.Error:
        return False
