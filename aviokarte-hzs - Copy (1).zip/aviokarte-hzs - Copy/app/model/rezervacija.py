class Rezervacija:

    def __init__(self, id, odakle, gde, povratak, datum, let):
        self.id = id
        self.odakle = odakle
        self.gde = gde
        self.povratak = povratak
        self.datum = datum
        self.let = let

    def to_dict(self):
        return {
            'id': self.id,
            'odakle': self.odakle,
            'gde': self.gde,
            'povratak': self.povratak,
            'datum': self.datum,
            'let_id': self.let.id
            }