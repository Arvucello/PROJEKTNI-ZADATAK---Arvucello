class Let:


    def __init__(self, id, odakle, gde, datum, let_uuid):
        self.id = id
        self.odakle = odakle
        self.gde = gde
        self.datum = datum
        self.let_uuid = let_uuid
        self.rezervacije = []

    def add_rezervacija(self, rezervacija):
        self.rezervacije.append(rezervacija)

    def to_dict(self):
        return {
            'id': self.id,
            'odakle': self.odakle,
            'gde': self.gde,
            'datum': self.datum,
            'rezervacije': [rezervacija.to_dict() for rezervacija in self.rezervacije]
        }