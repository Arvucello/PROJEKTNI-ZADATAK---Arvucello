var form = document.getElementById("forma");
form.addEventListener("submit", function (e) {
    e.preventDefault();
	var requestURL = window.location.origin +"/teams/"
    //var requestURL = "http://142.93.173.116:5000/teams/";

    var request = new XMLHttpRequest();

    request.open('GET', requestURL + sifraTima.value);
    request.responseType = 'json';
    request.send();

    request.onload = function () {
        var tim = request.response;
		if (tim["error"] != null) 
		{
			alert(tim["error"]);
			return;
		}
        //samo prikaz u konzoli zbog demonstracije
        var div = document.getElementById('prikaz');
        var myH1 = document.createElement('input');
        var label = document.createElement('p');
        label.textContent = 'Ime tima';
        div.appendChild(label);

        myH1.value = tim['name'];
        div.appendChild(myH1);
        var myPar = document.createElement('input');
        myPar.value = tim['description'];
        var label2 = document.createElement('p');
        label2.textContent = 'Opis tima';
        div.appendChild(label2);
        div.appendChild(myPar);

        var clanovi = tim['team_members'];
        ispisiClanove(clanovi, div);

    }

}, false);

function ispisiClanove(clanovi, div) {

    for (var j = 0; j < clanovi.length; j++) {
        var myArticle = document.createElement('article');
        var ime = document.createElement('input');
        var prezime = document.createElement('input');
        var email = document.createElement('input');
        var brojTelefona = document.createElement('input');
        var skola = document.createElement('input');
        var mestoSkole = document.createElement('input');
        var dugme = document.createElement('button');
        dugme.setAttribute('type', 'button');
        dugme.setAttribute('id' , j+1);
        dugme.onclick = brisi_clana(dugme.id);
        var dugmence = document.createElement('input');
        dugmence.value = "Izmeni podatke o članu";
        dugmence.setAttribute('type', 'submit');
        dugmence.setAttribute('id', j+1);
        dugmence.onclick = update_clana(dugmence.id);


        dugme.innerHTML = "Izbriši clana";
        ime.value = clanovi[j].first_name;
        prezime.value = clanovi[j].last_name;
        email.value = clanovi[j].email;
        brojTelefona.value = clanovi[j].phone_number;
        skola.value = clanovi[j].school;
        mestoSkole.value = clanovi[j].city;

        myArticle.appendChild(ime);
        myArticle.appendChild(prezime);
        myArticle.appendChild(email);
        myArticle.appendChild(brojTelefona);
        myArticle.appendChild(skola);
        myArticle.appendChild(mestoSkole);
        myArticle.appendChild(dugme);
        myArticle.appendChild(dugmence);

        myArticle.classList.add('clanoviTima');

        div.appendChild(myArticle);

    }
    
}

function brisi_clana(a){
    var requestURL = window.location.origin +"/clan/"

    var request = new XMLHttpRequest();

    request.open('DELETE', requestURL + a);
    request.responseType = 'json';
    request.send();
}
function update_clana(a){
    var requestURL = window.location.origin +"/clan/"

    var request = new XMLHttpRequest();

    request.open('PUT', requestURL + a);
    request.responseType = 'json';
    request.send();
}
/*
TESTIRANJE ZA BRISANJE
var requestURL = "http://142.93.173.116:5000/teams/";

var request = new XMLHttpRequest();

request.open('DELETE', requestURL + '0452b67e-8f12-4010-95c2-53481bb927a9');

request.send();
*/